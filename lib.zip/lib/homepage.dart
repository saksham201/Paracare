import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final items = ["Yes", "No"];
  String? value;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red[50],
      appBar: PreferredSize(
        preferredSize:
        Size.fromHeight(MediaQuery
            .of(context)
            .size
            .height * 0.08),
        child: AppBar(
          backgroundColor: Color(0xFFF3F5F8),
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
                //  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>OPDPatient()), (route) => false);
              },
              child: Icon(Icons.keyboard_backspace, color: Colors.black,)),
          automaticallyImplyLeading: true,
          title: Container(
              padding: EdgeInsets.all(8),
              width: MediaQuery
                  .of(context)
                  .size
                  .width * 0.4,
              child: Image.asset("images/complete logo.png")),

          actions: [
            Container(
              width: MediaQuery
                  .of(context)
                  .size
                  .width * 0.46,
              padding: EdgeInsets.all(8),
              child: TextField(
                autofocus: false,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: new BorderSide(color: Colors.grey)
                    ),
                    filled: true,
                    hintStyle: TextStyle(color: Colors.grey, fontSize: 12),
                    hintText: "Search Patient",
                    suffixIcon: Icon(Icons.search_outlined),
                    fillColor: Colors.white70),
              ),
            )
          ],
          elevation: 4,
        ),
      ),
      body:SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: 25,
                decoration: BoxDecoration(color: Colors.blue[900]),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text("IPD PATIENT",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top:2),
                  child: Icon(Icons.account_circle_rounded,color: Colors.blue,size: 100,),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 3.0),
                  child: Text("Mohan Kumar",style: TextStyle(fontSize: 20,color: Colors.blue[900],fontWeight: FontWeight.bold),),
                ),
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top:10,left: 40),
                    child: Icon(Icons.wc_sharp,color: Colors.grey),

                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 3),
                      child :(Text("SR Rawat",style: TextStyle(fontSize: 13,color: Colors.grey))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 110,top: 10),
                    child: Icon(Icons.male,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 3),
                    child: Text("Male",style: TextStyle(fontSize: 13,color: Colors.grey),),
                  ),

                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 40),
                    child: Icon(Icons.bloodtype,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 3),
                    child :(Text("A+",style: TextStyle(fontSize: 13,color: Colors.grey))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 150,top: 10),
                    child: Icon(Icons.ring_volume,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 8),
                    child: Text("Married",style: TextStyle(fontSize: 13,color: Colors.grey),),
                  ),


                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 40),
                    child: Icon(Icons.hourglass_empty,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 3),
                    child :(Text("12 Years 0 Months(04-08-2009)",style: TextStyle(fontSize: 13,color: Colors.grey))),
                  ),

                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 40),
                    child: Icon(Icons.phone,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 4),
                    child :(Text("9989897976",style: TextStyle(fontSize: 13,color: Colors.grey))),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 40),
                    child: Icon(Icons.location_on_outlined,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5,left: 3),
                    child :(Text("New Delhi",style: TextStyle(fontSize: 13,color: Colors.grey))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 80,top: 10),
                    child: Icon(Icons.mail_outline,color: Colors.grey),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 7,left: 6),
                    child: Text("Mohankumar43@gmail.com",style: TextStyle(fontSize: 11,color: Colors.grey),),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 47),
                    child :(Text("Any Known Allergies",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 47),
                    child :(Text("Remarks",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                ],
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Divider(
                  thickness: 1,
                  height: 1,
                  color: Colors.grey[600],
                ),
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 15),
                    child :(Text("Admission Date*",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 80),
                    child: Text("Case",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 4,left: 15),
                    child: Container(
                      height: 15,
                      width: 130,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.zero),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4,left: 63),
                    child: Container(
                      height: 15,
                      width: 145,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.zero),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),

                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 15),
                    child :(Text("Casuality",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 65),
                    child: Text("Old Patient",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 45),
                    child: Text("TPA",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 2,left: 15),
                      child:  Container(
                        width: 59,
                        height: 20,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey,width: 1),
                          color: Colors.white,
                        ),
                        child: DropdownButton<String>(
                          items: items.map(buildMenuItem).toList(),
                          onChanged: (value) => setState(() => this.value = value),
                          hint: Text("No"),
                          dropdownColor: Colors.white,

                        ),
                      ),

                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 2,left: 75),
                    child:  Container(
                      width: 90,
                      height: 20,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey,width: 1),
                        color: Colors.white,
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("No"),
                        dropdownColor: Colors.white,

                      ),
                    ),

                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 2,left: 23),
                    child:  Container(
                      height: 20,
                      width: 100,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey,width: 1)
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("Select"),
                        dropdownColor: Colors.white,

                      ),
                    ),

                  ),

                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10,left: 15),
                    child :(Text("Reference",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10,left: 40),
                    child: Text("Credit limit(Rs)",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10,left: 30),
                    child: Text("Consultant Doctor*",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top:1 ,left: 15),
                    child: Container(
                      height: 15,
                      width: 80,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.zero),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4,left: 30),
                    child: Container(
                      height: 15,
                      width: 100,
                      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.zero),
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 30),
                    child:  Container(
                      height: 20,
                      width: 100,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey,width: 1)
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("Select"),
                        dropdownColor: Colors.white,
                        icon: Icon(Icons.arrow_drop_down),

                      ),
                    ),

                  ),

                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 2,left: 15),
                    child :(Text("Bed Group",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),


                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15,top: 4),
                    child:  Container(
                      width: 300,
                      height: 20,
                      padding: const EdgeInsets.only(right: 5 ,left: 5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey,width: 1)
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("Select"),
                        dropdownColor: Colors.white,
                        icon: Icon(Icons.arrow_drop_down),

                      ),
                    ),

                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 15),
                    child :(Text("Bed Number*",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15,left: 120),
                    child: Text("Live Consultation",style: TextStyle(fontSize: 15,color: Colors.grey[600],fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15,top: 4),
                    child:  Container(
                      width: 100,
                      height: 20,
                      padding: const EdgeInsets.only(right: 5 ,left: 5),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.grey,width: 1)
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("Select"),
                        dropdownColor: Colors.white,
                        icon: Icon(Icons.arrow_drop_down),

                      ),
                    ),

                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 110,top: 4),
                    child:  Container(
                      width: 150,
                      height: 20,
                      padding: const EdgeInsets.only(right: 5 ,left: 5),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.grey,width: 1)
                      ),
                      child: DropdownButton<String>(
                        items: items.map(buildMenuItem).toList(),
                        onChanged: (value) => setState(() => this.value = value),
                        hint: Text("Select"),
                        dropdownColor: Colors.white,
                        icon: Icon(Icons.arrow_drop_down),

                      ),
                    ),

                  ),
                ],
              ),
              Center(
                child: ElevatedButton(
                  child: Text("SAVE"),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue[800],
                    onPrimary: Colors.white,
                    padding: EdgeInsets.all(5.0),
                  ),
                  onPressed: (){},
                ),

              ),



            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.blue[900],
        items: const<BottomNavigationBarItem> [
          BottomNavigationBarItem(
            icon: Icon(Icons.home,color: Colors.white,),
            title: Text("Home"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person,color: Colors.white,),
            title: Text("Profile",style: TextStyle(color: Colors.white),),

          ),

        ],
      ),
    );
  }
}
DropdownMenuItem<String> buildMenuItem(String item) => DropdownMenuItem(
    value: item,
    child: Text(
      item,
      style : TextStyle(fontSize:20),
    )
);
