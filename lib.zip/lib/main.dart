import 'package:flutter/material.dart';
import 'package:paracare_screen20/screen_feed.dart';
void main(){
  runApp(ScreenFeed());
}